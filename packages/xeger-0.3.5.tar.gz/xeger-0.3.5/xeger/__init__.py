from .xeger import Xeger

xeger = Xeger().xeger
