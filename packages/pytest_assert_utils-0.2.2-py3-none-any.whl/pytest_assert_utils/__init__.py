__version__ = '0.1.0'

from . import util
from .util import assert_dict_is_subset, assert_model_attrs
